<?php
$title = "Home";
$setHomeActive = "active";
include 'layout/_header.php';

include 'layout/navbar.php';
?>
<div class="container">
    <div class="row">
        

        <h2 class="text-center">Welcome to Our DIU Blood Management System</h2>



    </div>
</div>

<?php include 'layout/_footer.php'; ?>