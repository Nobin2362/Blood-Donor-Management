<?php
$title="About Us";$setAboutActive="active";
include 'layout/_header.php';

include 'layout/navbar.php';
?>

<div class="container">
    <div class="row text-center">
     
    </div>
</div>

<?php include 'layout/_footer.php'; ?>

