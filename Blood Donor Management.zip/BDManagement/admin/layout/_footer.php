<footer class="nav navbar-fixed-bottom">
<b>&COPY; All Right's Reserved DIU Blood Bank</b>
            <br>
</footer>



</body>
</html>
