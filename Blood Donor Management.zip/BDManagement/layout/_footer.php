<footer class="foter">
            <b>&COPY; All Right's Reserved DIU Blood Bank</b>
            <br>
</footer>



</body>
</html>
