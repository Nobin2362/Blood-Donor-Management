-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2021 at 07:59 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `donor`
--

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE `donors` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) DEFAULT NULL,
  `lname` varchar(20) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `b_type` varchar(3) NOT NULL,
  `bday` date NOT NULL,
  `h_address` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `don_date` date NOT NULL,
  `stats` varchar(20) NOT NULL,
  `temp` varchar(10) NOT NULL,
  `pulse` varchar(10) NOT NULL,
  `bp` varchar(10) NOT NULL,
  `weight` int(10) NOT NULL,
  `hemoglobin` varchar(15) NOT NULL,
  `hbsag` varchar(15) NOT NULL,
  `aids` varchar(15) NOT NULL,
  `malaria_smear` varchar(20) NOT NULL,
  `hematocrit` varchar(15) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `mobile` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`id`, `fname`, `mname`, `lname`, `sex`, `b_type`, `bday`, `h_address`, `city`, `don_date`, `stats`, `temp`, `pulse`, `bp`, `weight`, `hemoglobin`, `hbsag`, `aids`, `malaria_smear`, `hematocrit`, `phone`, `mobile`) VALUES
(12, 'Joy', '', 'Mia', 'male', 'A+', '1998-09-23', 'Badda', 'Dhaka', '2021-02-18', 'Normal', '36', '60', '80 | 120', 64, '16 - 18 gm/dl', 'Negative', 'Negative', 'Negative', '45 - 52%', '34566544', '01712345355'),
(13, 'Akash', '', 'Roy', 'male', 'A-', '1999-09-23', 'Gulistan', 'Dhaka', '2021-03-01', 'Normal', '37', '62', '79 | 120', 70, '14 - 17 gm/dl', 'Negative', 'Negative', 'Negative', '43 - 51%', '12346544', '01654334534'),
(14, 'pritue', '', 'Mondal', 'male', 'AB+', '1999-03-23', 'Jassore', 'Khulna', '2020-12-18', 'Normal', '36', '61', '80 | 120', 72, '16 - 17 gm/dl', 'Negative', 'Negative', 'Negative', '42 - 50%', '4567544', '015323456'),
(15, 'Sakawat', '', 'Hossain', 'male', 'AB-', '1999-05-20', 'Tinmor', 'Bogura', '2020-02-18', 'Normal', '37', '62', '79 | 118', 83, '15 - 17 gm/dl', 'Negative', 'Negative', 'Negative', '47 - 65%', '345665677', '01312345455'),
(16, 'Rizvey', '', 'Khan', 'male', 'O+', '2000-09-02', 'Tongi', 'Gazipur', '2021-04-01', 'Normal', '35', '61', '81 | 122', 80, '15 - 17 gm/dl', 'Negative', 'Negative', 'Negative', '44 - 49%', '23466544', '01543345355'),
(17, 'Leon', '', 'Mia', 'male', 'B-', '1999-02-21', 'Tongi', 'Gazipur', '2020-09-18', 'Normal', '36', '62', '84 | 126', 81, '13 - 17.6 gm/dl', 'Negative', 'Negative', 'Negative', '40 - 58%', '13266544', '01523245543'),
(18, 'Samia', '', 'Sultana', 'female', 'O-', '2000-02-03', 'Adalot paaraaa', 'Tangail', '2021-02-03', 'Normal', '35', '65', '80 | 120', 55, '15 - 18 gm/dl', 'Negative', 'Negative', 'Negative', '45 - 52%', '333444567', '01634567776'),
(19, 'Nahid', 'Sharif', '', 'Male', 'O+', '1998-03-02', 'Tangail', 'Dhaka', '2021-01-11', 'normal', '35', '70', '81 | 121', 90, '13.5 -17.5 gm/d', 'Negative', 'Negative', 'Negative', '40 - 51%', '34567778', '01543456756');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `m_name` varchar(20) DEFAULT NULL,
  `l_name` varchar(20) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `b_day` date NOT NULL,
  `prc_nr` int(20) NOT NULL,
  `designation` varchar(20) NOT NULL,
  `landline` varchar(15) DEFAULT NULL,
  `mobile_nr` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `f_name`, `m_name`, `l_name`, `username`, `password`, `b_day`, `prc_nr`, `designation`, `landline`, `mobile_nr`) VALUES
(1, 'Rasel', 'Hider', 'Nobin', 'admin', 'diudiu', '1997-08-24', 123456, 'Student', '2345678765', '01641021561'),
(18, 'Rasel', '', 'N', 'rasel_diu', 'diudiu', '1999-02-04', 606, 'Student', '34567890', '0134567890');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `b_type` varchar(10) NOT NULL,
  `address` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `dob`, `gender`, `b_type`, `address`, `city`, `mobile`, `created_at`) VALUES
(2, 'Tanjid', 'Ahmed', 'tanjid.555@gmail.com', '2020-02-11', 'Male', 'B-', 'Basail', 'Tangail', '01623454232', '2021-04-08 14:00:18'),
(3, 'Farzana', 'Khanam', 'farzana.23@diu.edu.b', '2001-02-01', 'Female', 'AB-', 'Ashulia', 'Dhaka', '0187425243', '2021-04-08 14:01:56'),
(4, 'Sathi', 'Khan', 'sathi.232@diu.edu.bd', '2000-02-10', 'Female', 'AB+', 'Ashulia', 'Dhaka', '0162456235', '2021-04-08 17:19:50'),
(5, 'Nodi', 'Khanam', 'Nodi.21@diu.edu.bd', '2002-07-01', 'Female', 'O-', 'Ashulia', 'Dhaka', '01532422522', '2021-04-08 17:20:16'),
(6, 'Rafi', 'Khan', 'rafi.2@diu.edu.bd', '2000-09-01', 'Male', 'A-', 'Tangail', 'Dhaka', '01321125243', '2021-04-08 14:05:36'),
(7, 'Hasan', 'Khan', 'hasan.234@gmail.com', '2020-02-12', 'Male', 'B+', 'Tongi', 'Gazipur', '0155223245542', '2021-04-08 14:05:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donors`
--
ALTER TABLE `donors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `prc_nr` (`prc_nr`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donors`
--
ALTER TABLE `donors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
